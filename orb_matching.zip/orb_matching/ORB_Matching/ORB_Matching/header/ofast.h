//
//  ofast.h
//  ORB_Matching
//
//  Created by SwChui on 2019/1/8.
//  Copyright © 2019年 SwChui. All rights reserved.
//

#ifndef ofast_h
#define ofast_h

#include <stdio.h>
#include "type.h"
#include "mat.h"



float gaussian(float sigma, float r);
Mat* gaussian_kernel(U8 radius, float sigma);
List* Dog(Mat* image);
Mat* get_dog_kernel(U8 radius, float sigma1, float sigma2);
void plot_points(Mat* color_image, List* key_points);
void plot_lines(Mat* color_image, List* key_points);
List* fast_detect(Mat* image);
List* ofast_detect(Mat* image,int N);
double harrisscore(Mat* image, Points point);
List* harris_top(Mat* image, List* keypoints, int N);
List* orient(Mat* image, List* keypoints,int radius);
#endif /* ofast_h */
