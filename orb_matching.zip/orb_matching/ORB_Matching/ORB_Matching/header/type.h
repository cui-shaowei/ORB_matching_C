//
//  type.h
//  ORB_Matching
//
//  Created by SwChui on 2019/1/8.
//  Copyright © 2019年 SwChui. All rights reserved.
//

#ifndef type_h
#define type_h

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

typedef  unsigned char  U8 ;
typedef  unsigned short U16 ;
typedef  unsigned int   U32 ;


#define MAX(a,b)  (((a)>(b))?(a):(b))
#define MIN(a,b)  (((a)>(b))?(b):(a))
#define ABS(a)    MAX(a,0)
#define PI 3.1415926

typedef struct Points{
    U16 row;
    U16 col;
}Points;

typedef struct ofastpoint{
    U16 geo_row;
    U16 geo_col;
    double theta;
}ofastpoint;

typedef struct orbpoint{
    U16 row;
    U16 col;
    bool descriptor[256];
}orbpoint;

typedef struct matchpoints{
    U16 row1;
    U16 col1;
    U16 row2;
    U16 col2;
}matchpoints;

typedef struct Node{
    struct Node* next;
    void* data;
}Node;

typedef struct List{
    struct Node* start;
    struct Node* end;
    U16 length;
    size_t bytes;
}List;

List* init_List(size_t bytes);
int push(List* list, void* data);

#endif /* type_h */
