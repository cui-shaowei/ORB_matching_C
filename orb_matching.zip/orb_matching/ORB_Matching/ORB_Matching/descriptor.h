//
//  descriptor.h
//  ORB_Matching
//
//  Created by SwChui on 2019/1/9.
//  Copyright © 2019年 SwChui. All rights reserved.
//

#ifndef descriptor_h
#define descriptor_h

#include <stdio.h>
#include "type.h"
#include "mat.h"
#include <math.h>
#include <stdbool.h>


List* compute_orb(Mat* image, List* keypoints);




#endif /* descriptor_h */
