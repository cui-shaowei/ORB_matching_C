//
//  matching.c
//  ORB_Matching
//
//  Created by SwChui on 2019/1/9.
//  Copyright © 2019年 SwChui. All rights reserved.
//

#include "matching.h"
matchpoints* init_matchpoints(U16 row1, U16 col1,U16 row2, U16 col2){
    matchpoints* point = malloc(sizeof(matchpoints));
    point->col1 = col1;
    point->row1 = row1;
    point->col2 = col2;
    point->row2 = row2;
    return point;
}

List* matching(List* keypoints1, List* keypoints2){
    
    List* matching_keypoints=init_List(sizeof(matchpoints));
    
    for(Node* pointer1 = keypoints1->start; pointer1 != NULL; pointer1 = pointer1->next){
        orbpoint* descriptor1 = pointer1->data;
        for(Node* pointer2 = keypoints2->start; pointer2 != NULL; pointer2 = pointer2->next){
            orbpoint* descriptor2 = pointer2->data;
            int success_num=0;
            for(int k=0;k<256;k++){
                if (descriptor1->descriptor[k] == descriptor2->descriptor[k]){
                    success_num++;
                }
            }
            if(success_num>225){
                push(matching_keypoints, init_matchpoints(descriptor1->row, descriptor1->col, descriptor2->row, descriptor2->col+1024));
            }
        }
    }
        return matching_keypoints;
}
