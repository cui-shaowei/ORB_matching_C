//
//  ofast.c
//  ORB_Matching
//
//  Created by SwChui on 2019/1/8.
//  Copyright © 2019年 SwChui. All rights reserved.
//

#include "ofast.h"
#include "mat.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#include "bmp.h"
#define Compare(X, Y) ((X)>=(Y))

Points* init_point(U16 row, U16 col){
    Points* points = malloc(sizeof(Points));
    points->col = col;
    points->row = row;
    return points;
}
ofastpoint* init_ofastpoint(U16 row, U16 col, double theta){
    ofastpoint* point = malloc(sizeof(ofastpoint));
    point->geo_col = col;
    point->geo_row = row;
    point->theta=theta;
    return point;
}

//float gaussian(float sigma, float r){
//    return exp(-pow(r,2) / (2*pow(sigma,2))) / (2*PI*sigma);
//}
//
//Mat* gaussian_kernel(U8 radius, float sigma){
//    U16 height = 2*radius + 1;
//    U16 width = 2*radius + 1;
//    Mat* kernel = init_mat(height, width, 0,Float);
//    float* pointer;
//    
//    for(int row = 0; row<height;row++){
//        for(int col = 0; col < width; col++){
//            pointer = locate(kernel, row, col);
//            float r = sqrt(pow(row - radius,2) + pow(col - radius,2))/radius;
//            *pointer = gaussian(sigma, r);
//        }
//    }
//    return kernel;
//}
///*check if this point is extreme point*/
//bool check_extreme(Mat* scala_space[],U8 level,U16 row,U16 col){
//    if(level == 0 || level == 3){
//        fprintf(stderr,"check_max level error");
//        return false;
//    }
//    float threshold = 0.8;
//    U8 is_extreme = true;
//    
//    float* origin = locate(scala_space[level], row, col);
//    /*check maxmum*/
//    for(U8 k = level -1;k < level + 2; k++){
//        for(U16 i = row - 1;i < row + 2;i++){
//            for(U16 j = col - 1;j < col + 2;j++){
//                if(i == row && j == col && k == level)
//                    continue;
//                float* compare = locate(scala_space[k], i, j);
//                if(*compare > *origin - threshold)
//                    //return false;
//                    is_extreme = false;
//            }
//        }
//        if(is_extreme == false)
//            break;
//    }
//    if(is_extreme == false)
//        is_extreme = true;
//    else
//        return is_extreme;
//    /*check minmum*/
//    for(U8 k = level -1;k < level + 2; k++){
//        for(U16 i = row - 1;i < row + 2;i++){
//            for(U16 j = col - 1;j < col + 2;j++){
//                if(i == row && j == col && k == level)
//                    continue;
//                float* compare = locate(scala_space[k], i, j);
//                if(*compare < *origin + threshold)
//                    is_extreme = false;
//            }
//        }
//        if(is_extreme == false)
//            break;
//    }
//    
//    return is_extreme;
//}
//
//List* local_max(Mat** scala_space){
//    U16 length = 4;
//    List* key_points = init_List(sizeof(Points));
//    U16 height = scala_space[0]->height;
//    U16 width = scala_space[0]->width;
//    for(U8 k = 1; k < length - 1; k++){
//        for(U16 row = 4; row< height-4; row++){
//            for(U16 col=4; col < width-4; col++){
//                if(check_extreme(scala_space, k,row,col))
//                    push(key_points,init_point(row,col));
//            }
//        }
//    }
//    return key_points;
//}
//
//Mat* get_dog_kernel(U8 radius, float sigma1, float sigma2){
//    Mat* kernel = image_sub(gaussian_kernel(radius,sigma1),
//                            gaussian_kernel(radius,sigma2));
//    float sum = 0;
//    for(U16 row = 0; row < 2*radius + 1; row++){
//        for(U16 col=0; col < 2*radius + 1; col++){
//            float* pointer = locate(kernel, row, col);
//            sum = sum + *pointer;
//        }
//    }
//    return kernel;
//}
//
//List* Dog(Mat* image){
//    float sigma = 0.3;
//    int scale = 4;
//    U8 radius = 2;
//    
//    Mat** scale_space = malloc(sizeof(Mat*));
//    for(int k = 1; k <scale+1; k++){
//        Mat* dog_kernel = get_dog_kernel(radius,sigma*2,sigma);
//        sigma = sigma*2;
//        print_mat(dog_kernel);
//        scale_space[k-1] = conv(image, dog_kernel, 1, dog_kernel->height/2); // keep the scale is the same as the origin image
//    }
//    List* key_point = local_max(scale_space);
//    
//    
//    for(int i = 0; i < 4; i++){
//        normalize_image(scale_space[i]);
//        Mat* img = float2uchar(scale_space[i]);
//        char path[20];
//        sprintf(path,"level-%d.bmp",(i+1));
//        write_bmp(img, path);
//    }
//    return key_point;
//}


List* fast_detect(Mat* image){
    int width=image->width;
    int height=image->height;
    List* key_points = init_List(sizeof(Points));
    
    //Points* corners;
    
    Points* pre_corners;
    int rsize=512;
    pre_corners=(Points*)malloc(sizeof(Points)*rsize);
    int num_corners=0;
    
    bool iscorner;
    for(int i=30;i<height-29;i++){
        for(int j=30;j<width-29;j++){
            U8* loc0=locate(image,i,j);
            U8 T=*loc0*0.2;
            //float loc111=*loc0;
            U8* loc1=locate(image, i-3, j);
            U8* loc2=locate(image, i-3, j+1);
            U8* loc3=locate(image, i-2, j+2);
            U8* loc4=locate(image, i-1, j+3);
            U8* loc5=locate(image, i, j+3);
            U8* loc6=locate(image, i+1, j+3);
            U8* loc7=locate(image, i+2, j+2);
            U8* loc8=locate(image, i+3, j+1);
            U8* loc9=locate(image, i+3, j);
            U8* loc10=locate(image, i+3, j-1);
            U8* loc11=locate(image, i+2, j-2);
            U8* loc12=locate(image, i+1, j-3);
            U8* loc13=locate(image, i, j-3);
            U8* loc14=locate(image, i-1, j-3);
            U8* loc15=locate(image, i-2, j-2);
            U8* loc16=locate(image, i-3, j-1);
            iscorner=false;
            if(*loc1-*loc0>T && *loc5-*loc0>T && *loc9-*loc0>T){//123
                if(*loc2-*loc0>T && *loc3-*loc0>T && *loc4-*loc0>T && *loc6-*loc0>T && *loc7-*loc0>T && *loc8-*loc0>T && *loc10-*loc0>T && *loc11-*loc0>T && *loc12-*loc0>T){
                    iscorner=true;
                }
                if(*loc2-*loc0>T && *loc3-*loc0>T && *loc4-*loc0>T && *loc6-*loc0>T && *loc7-*loc0>T && *loc8-*loc0>T && *loc10-*loc0>T && *loc11-*loc0>T && *loc16-*loc0>T){
                    iscorner=true;
                }
                if(*loc2-*loc0>T && *loc3-*loc0>T && *loc4-*loc0>T && *loc6-*loc0>T && *loc7-*loc0>T && *loc8-*loc0>T && *loc10-*loc0>T && *loc15-*loc0>T && *loc16-*loc0>T){
                    iscorner=true;
                }
                if(*loc2-*loc0>T && *loc3-*loc0>T && *loc4-*loc0>T && *loc6-*loc0>T && *loc7-*loc0>T && *loc8-*loc0>T && *loc14-*loc0>T && *loc15-*loc0>T && *loc16-*loc0>T){
                    iscorner=true;
                }
            }
            if(*loc13-*loc0>T && *loc5-*loc0>T && *loc9-*loc0>T){//234
                if(*loc6-*loc0>T && *loc7-*loc0>T && *loc8-*loc0>T && *loc10-*loc0>T && *loc11-*loc0>T && *loc12-*loc0>T && *loc14-*loc0>T && *loc15-*loc0>T && *loc16-*loc0>T){
                    iscorner=true;
                }
                if(*loc6-*loc0>T && *loc7-*loc0>T && *loc8-*loc0>T && *loc10-*loc0>T && *loc11-*loc0>T && *loc12-*loc0>T && *loc14-*loc0>T && *loc15-*loc0>T && *loc4-*loc0>T){
                    iscorner=true;
                }
                if(*loc6-*loc0>T && *loc7-*loc0>T && *loc8-*loc0>T && *loc10-*loc0>T && *loc11-*loc0>T && *loc12-*loc0>T && *loc14-*loc0>T && *loc3-*loc0>T && *loc4-*loc0>T){
                    iscorner=true;
                }
                if(*loc6-*loc0>T && *loc7-*loc0>T && *loc8-*loc0>T && *loc10-*loc0>T && *loc11-*loc0>T && *loc12-*loc0>T && *loc2-*loc0>T && *loc3-*loc0>T && *loc4-*loc0>T){
                    iscorner=true;
                }
            }
            if(*loc1-*loc0>T && *loc5-*loc0>T && *loc13-*loc0>T){//124
                if(*loc6-*loc0>T && *loc7-*loc0>T && *loc8-*loc0>T && *loc2-*loc0>T && *loc3-*loc0>T && *loc4-*loc0>T && *loc14-*loc0>T && *loc15-*loc0>T && *loc16-*loc0>T){
                    iscorner=true;
                }
                if(*loc6-*loc0>T && *loc7-*loc0>T && *loc12-*loc0>T && *loc2-*loc0>T && *loc3-*loc0>T && *loc4-*loc0>T && *loc14-*loc0>T && *loc15-*loc0>T && *loc16-*loc0>T){
                    iscorner=true;
                }
                if(*loc6-*loc0>T && *loc11-*loc0>T && *loc12-*loc0>T && *loc2-*loc0>T && *loc3-*loc0>T && *loc4-*loc0>T && *loc14-*loc0>T && *loc15-*loc0>T && *loc16-*loc0>T){
                    iscorner=true;
                }
                if(*loc10-*loc0>T && *loc11-*loc0>T && *loc12-*loc0>T && *loc2-*loc0>T && *loc3-*loc0>T && *loc4-*loc0>T && *loc14-*loc0>T && *loc15-*loc0>T && *loc16-*loc0>T){
                    iscorner=true;
                }
            }
            if(*loc1-*loc0>T && *loc13-*loc0>T && *loc9-*loc0>T){//134
                if( *loc10-*loc0>T && *loc11-*loc0>T && *loc12-*loc0>T && *loc14-*loc0>T && *loc15-*loc0>T && *loc16-*loc0>T && *loc2-*loc0>T && *loc3-*loc0>T && *loc4-*loc0>T){
                    iscorner=true;
                }
                if( *loc10-*loc0>T && *loc11-*loc0>T && *loc12-*loc0>T && *loc14-*loc0>T && *loc15-*loc0>T && *loc16-*loc0>T && *loc8-*loc0>T && *loc2-*loc0>T && *loc3-*loc0>T){
                    iscorner=true;
                }
                if( *loc10-*loc0>T && *loc11-*loc0>T && *loc12-*loc0>T && *loc14-*loc0>T && *loc15-*loc0>T && *loc16-*loc0>T && *loc8-*loc0>T && *loc2-*loc0>T && *loc7-*loc0>T){
                    iscorner=true;
                }
                if( *loc10-*loc0>T && *loc11-*loc0>T && *loc12-*loc0>T && *loc14-*loc0>T && *loc15-*loc0>T && *loc16-*loc0>T && *loc8-*loc0>T && *loc6-*loc0>T && *loc7-*loc0>T){
                    iscorner=true;
                }
            }
           
            if(*loc0-*loc1>T && *loc0-*loc5>T && *loc0-*loc9>T){
                if(*loc0-*loc2>T && *loc0-*loc3>T && *loc0-*loc4>T && *loc0-*loc6>T && *loc0-*loc7>T && *loc0-*loc8>T && *loc0-*loc10>T && *loc0-*loc11>T && *loc0-*loc12>T){
                    iscorner=true;
                }
                if(*loc0-*loc2>T && *loc0-*loc3>T && *loc0-*loc4>T && *loc0-*loc6>T && *loc0-*loc7>T && *loc0-*loc8>T && *loc0-*loc10>T && *loc0-*loc11>T && *loc0-*loc16>T){
                    iscorner=true;
                }
                if(*loc0-*loc2>T && *loc0-*loc3>T && *loc0-*loc4>T && *loc0-*loc6>T && *loc0-*loc7>T && *loc0-*loc8>T && *loc0-*loc10>T && *loc0-*loc15>T && *loc0-*loc16>T){
                    iscorner=true;
                }
                if(*loc0-*loc2>T && *loc0-*loc3>T && *loc0-*loc4>T && *loc0-*loc6>T && *loc0-*loc7>T && *loc0-*loc8>T && *loc0-*loc14>T && *loc0-*loc15>T && *loc0-*loc16>T){
                    iscorner=true;
                }
            }
            if(*loc0-*loc13>T && *loc0-*loc5>T && *loc0-*loc9>T){
                if(*loc0-*loc14>T && *loc0-*loc15>T && *loc0-*loc16>T && *loc0-*loc6>T && *loc0-*loc7>T && *loc0-*loc8>T && *loc0-*loc10>T && *loc0-*loc11>T && *loc0-*loc12>T){
                    iscorner=true;
                }
                if(*loc0-*loc14>T && *loc0-*loc15>T && *loc0-*loc4>T && *loc0-*loc6>T && *loc0-*loc7>T && *loc0-*loc8>T && *loc0-*loc10>T && *loc0-*loc11>T && *loc0-*loc12>T){
                    iscorner=true;
                }
                if(*loc0-*loc14>T && *loc0-*loc3>T && *loc0-*loc4>T && *loc0-*loc6>T && *loc0-*loc7>T && *loc0-*loc8>T && *loc0-*loc10>T && *loc0-*loc11>T && *loc0-*loc12>T){
                    iscorner=true;
                }
                if(*loc0-*loc2>T && *loc0-*loc3>T && *loc0-*loc4>T && *loc0-*loc6>T && *loc0-*loc7>T && *loc0-*loc8>T && *loc0-*loc10>T && *loc0-*loc11>T && *loc0-*loc12>T){
                    iscorner=true;
                }
            }
            if(*loc0-*loc1>T && *loc0-*loc5>T && *loc0-*loc13>T){
                if(*loc0-*loc14>T && *loc0-*loc15>T && *loc0-*loc16>T && *loc0-*loc6>T && *loc0-*loc7>T && *loc0-*loc8>T && *loc0-*loc2>T && *loc0-*loc3>T && *loc0-*loc4>T){
                    iscorner=true;
                }
                if(*loc0-*loc14>T && *loc0-*loc15>T && *loc0-*loc16>T && *loc0-*loc6>T && *loc0-*loc7>T && *loc0-*loc12>T && *loc0-*loc2>T && *loc0-*loc3>T && *loc0-*loc4>T){
                    iscorner=true;
                }
                if(*loc0-*loc14>T && *loc0-*loc15>T && *loc0-*loc16>T && *loc0-*loc6>T && *loc0-*loc11>T && *loc0-*loc12>T && *loc0-*loc2>T && *loc0-*loc3>T && *loc0-*loc4>T){
                    iscorner=true;
                }
                if(*loc0-*loc14>T && *loc0-*loc15>T && *loc0-*loc16>T && *loc0-*loc10>T && *loc0-*loc11>T && *loc0-*loc12>T && *loc0-*loc2>T && *loc0-*loc3>T && *loc0-*loc4>T){
                    iscorner=true;
                }
            }
            if(*loc0-*loc1>T && *loc0-*loc13>T && *loc0-*loc9>T){
                if(*loc0-*loc14>T && *loc0-*loc15>T && *loc0-*loc16>T && *loc0-*loc10>T && *loc0-*loc11>T && *loc0-*loc12>T && *loc0-*loc2>T && *loc0-*loc3>T && *loc0-*loc4>T){
                    iscorner=true;
                }
                if(*loc0-*loc14>T && *loc0-*loc15>T && *loc0-*loc16>T && *loc0-*loc10>T && *loc0-*loc11>T && *loc0-*loc12>T && *loc0-*loc2>T && *loc0-*loc3>T && *loc0-*loc8>T){
                    iscorner=true;
                }
                if(*loc0-*loc14>T && *loc0-*loc15>T && *loc0-*loc16>T && *loc0-*loc10>T && *loc0-*loc11>T && *loc0-*loc12>T && *loc0-*loc2>T && *loc0-*loc7>T && *loc0-*loc8>T){
                    iscorner=true;
                }
                if(*loc0-*loc14>T && *loc0-*loc15>T && *loc0-*loc16>T && *loc0-*loc10>T && *loc0-*loc11>T && *loc0-*loc12>T && *loc0-*loc6>T && *loc0-*loc7>T && *loc0-*loc8>T){
                    iscorner=true;
                }
            }
            if(iscorner==false){
                continue;
            }
            if(num_corners == rsize)
            {
                rsize*=2;
                pre_corners = (Points*)realloc(pre_corners, sizeof(Points)*rsize);
            }
            if(iscorner==true){
                pre_corners[num_corners].row=i;
                pre_corners[num_corners].col=j;
                num_corners++;
            }
        }
    }
    int* scores = (int*)malloc(sizeof(int)* num_corners);
    for(int k=0;k<num_corners;k++){
        int i=pre_corners[k].row;
        int j=pre_corners[k].col;
        U8* loc0=locate(image,i,j);
        U8* loc1=locate(image, i-3, j);
        U8* loc2=locate(image, i-3, j+1);
        U8* loc3=locate(image, i-2, j+2);
        U8* loc4=locate(image, i-1, j+3);
        U8* loc5=locate(image, i, j+3);
        U8* loc6=locate(image, i+1, j+3);
        U8* loc7=locate(image, i+2, j+2);
        U8* loc8=locate(image, i+3, j+1);
        U8* loc9=locate(image, i+3, j);
        U8* loc10=locate(image, i+3, j-1);
        U8* loc11=locate(image, i+2, j-2);
        U8* loc12=locate(image, i+1, j-3);
        U8* loc13=locate(image, i, j-3);
        U8* loc14=locate(image, i-1, j-3);
        U8* loc15=locate(image, i-2, j-2);
        U8* loc16=locate(image, i-3, j-1);
        scores[k]=abs(*loc1-*loc0)+abs(*loc2-*loc0)+abs(*loc3-*loc0)+abs(*loc4-*loc0)+abs(*loc5-*loc0)+abs(*loc6-*loc0)+abs(*loc7-*loc0)+abs(*loc8-*loc0)+abs(*loc9-*loc0)+abs(*loc10-*loc0)+abs(*loc11-*loc0)+abs(*loc12-*loc0)+abs(*loc13-*loc0)+abs(*loc14-*loc0)+abs(*loc15-*loc0)+abs(*loc16-*loc0);
        
    }
    
    
    //int num_nonmax=0;
    int last_row;
    int* row_start;
    //Points* corners_nonmax;
    int i,j;
    const int sz = (int)num_corners;
    
    /*Point above points (roughly) to the pixel above the one of interest, if there
     is a feature there.*/
    int point_above = 0;
    int point_below = 0;
    
    if(num_corners < 1)
    {
        return 0;
    }
    
    //corners_nonmax = (Points*)malloc(num_corners * sizeof(Points));
    
    /* Find where each row begins
     (the corners are output in raster scan order). A beginning of -1 signifies
     that there are no corners on that row. */
    last_row = pre_corners[num_corners-1].row;
    row_start = (int*)malloc((last_row+1)*sizeof(int));
    
    for( i=0; i < last_row+1; i++)
        row_start[i] = -1;
    
    {
        int prev_row = -1;
        for( i=0; i< num_corners; i++)
            if(pre_corners[i].row != prev_row)
            {
                row_start[pre_corners[i].row] = i;
                prev_row = pre_corners[i].row;
            }
    }
    
    
    
    for(i=0; i < sz; i++)
    {
        int score = scores[i];
        Points pos = pre_corners[i];
        
        /*Check left */
        if(i > 0)
            if(pre_corners[i-1].col == pos.col-1 && pre_corners[i-1].row == pos.row && Compare(scores[i-1], score))
                continue;
        
        /*Check right*/
        if(i < (sz - 1))
            if(pre_corners[i+1].col == pos.col+1 && pre_corners[i+1].row == pos.row && Compare(scores[i+1], score))
                continue;
        
        /*Check above (if there is a valid row above)*/
        if(pos.row != 0 && row_start[pos.row - 1] != -1)
        {
            /*Make sure that current point_above is one
             row above.*/
            if(pre_corners[point_above].row < pos.row - 1)
                point_above = row_start[pos.row-1];
            
            /*Make point_above point to the first of the pixels above the current point,
             if it exists.*/
            for(; pre_corners[point_above].row < pos.row && pre_corners[point_above].col < pos.col - 1; point_above++)
            {}
            
            
            for( j=point_above; pre_corners[j].row < pos.row && pre_corners[j].col <= pos.col + 1; j++)
            {
                int x = pre_corners[j].col;
                if( (x == pos.col - 1 || x ==pos.col || x == pos.col+1) && Compare(scores[j], score))
                    goto cont;
            }
            
        }
        
        /*Check below (if there is anything below)*/
        if(pos.row != last_row && row_start[pos.row + 1] != -1 && point_below < sz) /*Nothing below*/
        {
            if(pre_corners[point_below].row < pos.row + 1)
                point_below = row_start[pos.row+1];
            
            /* Make point below point to one of the pixels belowthe current point, if it
             exists.*/
            for(; point_below < sz && pre_corners[point_below].row == pos.row+1 && pre_corners[point_below].col < pos.col - 1; point_below++)
            {}
            
            for( j=point_below; j < sz && pre_corners[j].row == pos.row+1 && pre_corners[j].col <= pos.col + 1; j++)
            {
                int x = pre_corners[j].col;
                if( (x == pos.col - 1 || x ==pos.col || x == pos.col+1) && Compare(scores[j],score))
                    goto cont;
            }
        }
//        U16 tempx=16;
//        U16 tempy=200;
//        Points* xyyy = init_point(tempx,tempy);
        push(key_points,init_point(pre_corners[i].row,pre_corners[i].col));
        //push(key_points,xyyy);c
        //corners_nonmax[num_nonmax++] = pre_corners[i];
    cont:
        ;
    }
    free(pre_corners);
    free(scores);
    free(row_start);
    //free(corners_nonmax);
    
    return key_points;
}

double harrisscore(Mat* image, Points point){
    double harris_score;
//    U8* loc5=locate(image, point.row, point.col);
//    U8* loc1=locate(image, point.row-1, point.col-1);
//    U8* loc2=locate(image, point.row-1, point.col);
//    U8* loc3=locate(image, point.row-1, point.col+1);
//    U8* loc4=locate(image, point.row, point.col-1);
//    U8* loc6=locate(image, point.row, point.col+1);
//    U8* loc7=locate(image, point.row+1, point.col-1);
//    U8* loc8=locate(image, point.row+1, point.col);
//    U8* loc9=locate(image, point.row+1, point.col+1);
    double a11=0,a12=0,a21=0,a22=0;
    for(int i=0;i<3;i++){
        for(int j=0;j<3;j++){
            U8* IX_zero=locate(image, point.row-1+i, point.col-1+j);
            U8* IX_next=locate(image, point.row-1+i, point.col-1+j+1);
           double IX=*IX_next-*IX_zero;
            
            U8* IY_zero=locate(image, point.row-1+i, point.col-1+j);
            U8* IY_next=locate(image, point.row-1+i+1, point.col-1+j);
            double IY=*IY_next-*IY_zero;
            a11+=IX*IX;
            a12+=IX*IY;
            a21+=IX*IY;
            a22+=IY*IY;
        }
    }
   
    double detM=a11*a22-a12*a21;
    double trackM=a11+a22;
    harris_score=detM-0.05*trackM*trackM;
    return harris_score;
}
List* harris_top(Mat* image, List* keypoints, int N){
    double* harris_score=(double*)malloc(keypoints->length * sizeof(double));
    int keypoints_num=0;
    for(Node* pointer = keypoints->start; pointer != NULL; pointer = pointer->next){
        Points* point = pointer->data;
        harris_score[keypoints_num]=harrisscore(image,*point);
        keypoints_num++;
    }
    double temp;
    for(int i=0;i<keypoints->length;i++){
        for(int j=0;j<keypoints->length-i;j++){
            if(harris_score[j]<harris_score[j+1]){
                temp=harris_score[j];
                harris_score[j]=harris_score[j+1];
                harris_score[j+1]=temp;
            }
        }
    }
    List* harris_keypoints=init_List(sizeof(Points));
    for(Node* pointer = keypoints->start; pointer != NULL; pointer = pointer->next){
        Points* point = pointer->data;
        double tempHarrisTemp=harrisscore(image,*point);
        if(tempHarrisTemp>=harris_score[N-1]){
            push(harris_keypoints, point);
        }
        keypoints_num++;
    }
    return harris_keypoints;
}
List* orient(Mat* image, List* keypoints,int radius){
    List* ofast_keypoints=init_List(sizeof(ofastpoint));
    for(Node* pointer = keypoints->start; pointer != NULL; pointer = pointer->next){
        Points* point = pointer->data;
        double m01=0,m10=0;
        for(int i=-radius;i<=radius;i++){
            for(int j=-radius;j<radius;j++){
                U8* loc=locate(image, point->row+i, point->col+j);
                m01+=*loc*i;
                m10+=*loc*j;
            }
        }
        double theta=180*atan2(m01, m10)/PI;
        if(theta<0){
            theta=360+theta;
        }
        push(ofast_keypoints, init_ofastpoint(point->row, point->col, theta));
    }
    
    return ofast_keypoints;
}
void plot_points(Mat* color_image, List* key_points){
    if(color_image->channels != 3){
        return;
    }
    RGB red;
    red.G = 255;
    U16 height = color_image->height;
    U16 width = color_image->width;
    
    for(Node* pointer = key_points->start; pointer != NULL; pointer = pointer->next){
        Points* points = pointer->data;
        RGB* to = locate(color_image, points->row, points->col);
        if(points->row > 1 && points->row < height- 2
           && points->col > 1&& points->col < width -2){
            *to = red;
            *(to - 1) = red;
            *(to + 1) = red;
            *(to - 2) = red;
            *(to + 2) = red;
            *(to + width) = red;
            *(to - width) = red;
            *(to + width*2) = red;
            *(to - width*2) = red;
        }
    }
}
void plot_lines(Mat* color_image, List* key_points){
    if(color_image->channels != 3){
        return;
    }
    RGB color;
    color.G=255;
    //U16 height = color_image->height;
    U16 width = color_image->width;
    for(Node* pointer = key_points->start; pointer != NULL; pointer = pointer->next){
        matchpoints* points = pointer->data;
        RGB* from = locate(color_image, points->row1, points->col1);
        RGB* to =locate(color_image, points->row2, points->col2);
        double x1=points->col1;
        double y1=points->row1;
        double x2=points->col2;
        double y2=points->row2;
        *to = color;
        *(to - 1) = color;
        *(to + 1) = color;
        *(to - 2) = color;
        *(to + 2) = color;
        *(to + width) = color;
        *(to - width) = color;
        *(to + width*2) = color;
        *(to - width*2) = color;
        *from = color;
        *(from - 1) = color;
        *(from + 1) = color;
        *(from - 2) = color;
        *(from + 2) = color;
        *(from + width) = color;
        *(from - width) = color;
        *(from + width*2) = color;
        *(from - width*2) = color;
        //for(RGB* temp=from;temp<to;temp=temp+width+(points->row2)){
         //   *temp=color;
        //}
        
        if(y2==y1){
            for(U16 i=x1;i<x2;i++){
                RGB* temp=locate(color_image, y1, i);
                *temp=color;
            }
        }
        else{
            double a=(y2-y1)/(x2-x1);
            double b=y1-a*x1;
            for(U16 i=x1;i<x2;i++){
                RGB* temp=locate(color_image,a*i+b, i);
                *temp=color;
            }
        }
       
    }
}

List* ofast_detect(Mat* image,int N) {
    List* keypoints=fast_detect(image);
    List* harris_keypoints=harris_top(image,keypoints,N);
    List* ofast_keypoints=orient(image, harris_keypoints,3);
    return ofast_keypoints;
}
