//
//  bmp.h
//  ORB_Matching
//
//  Created by SwChui on 2019/1/8.
//  Copyright © 2019年 SwChui. All rights reserved.
//

#ifndef bmp_h
#define bmp_h

#include "mat.h"

Mat* read_bmp(char* path);
int write_bmp(Mat* image, char* path);

typedef struct RGBQUAD{
    U8 R;
    U8 G;
    U8 B;
    U8 reserver;
}RGBQUAD;

#endif /* bmp_h */
