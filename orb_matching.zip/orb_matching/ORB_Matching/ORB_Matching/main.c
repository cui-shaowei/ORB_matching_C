//
//  main.c
//  ORB_Matching
//
//  Created by SwChui on 2019/1/2.
//  Copyright © 2019年 SwChui. All rights reserved.
//
#include <stdio.h>
#include "bmp.h"
#include "ofast.h"
#include "descriptor.h"
#include "type.h"
#include "matching.h"


int main(int argc, const char * argv[]) {
    // insert code here...
    //Mat* color_img=read_bmp("1.bmp");
    Mat* color_image1 = read_bmp("1.bmp");    //read rgb image
   // Mat* color_image1 = read_bmp(argv[0]);
    Mat* gray_image1 = RGB2Gray(color_image1); //convert color image to gray image
    //Mat* float_image = uchar2float(gray_image); //convert U8 to float
    List* key_points1=ofast_detect(gray_image1,500);
    List* orb_descriptor1=compute_orb(gray_image1,key_points1);
    //plot_points(color_image1, key_points1);
    //write_bmp(color_image1,"/Users/cuishaowei/Desktop/1_fast.bmp");
    //Mat* color_image2 = read_bmp(argv[1]);
    Mat* color_image2 = read_bmp("2.bmp");    //read rgb image
    Mat* gray_image2 = RGB2Gray(color_image2); //convert color image to gray image
    //Mat* float_image = uchar2float(gray_image); //convert U8 to float
    List* key_points2=ofast_detect(gray_image2,500);
    List* orb_descriptor2=compute_orb(gray_image2,key_points2);
    //plot_points(color_image2, key_points2);
    Mat* mergeimage=merge_mat(color_image1, color_image2);
    
    
    List* matching_keypoints=matching(orb_descriptor1, orb_descriptor2);
    plot_lines(mergeimage, matching_keypoints);
    
    write_bmp(mergeimage,"orbmatching_results.bmp");
    
    //printf("Hello, World!\n Cui xiaohuan");
    return 0;
}
